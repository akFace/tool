

android 需要在 AndroidManifest.xml 里面增加 activity
<activity
    android:name="com.food4u.user.wxapi.WXEntryActivity"
    android:exported="true"
    android:label="@string/app_name"></activity>



ios 需要再info.plist 
1、 LSApplicationQueriesSchemes 增加
    wechat
    weixin
2、URL Types 里面增加
    identifier: weixin
    URL Schemes: 你的appid